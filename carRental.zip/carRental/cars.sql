-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2022 at 02:57 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cars`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked`
--

CREATE TABLE `booked` (
  `bid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `car_id` int(11) NOT NULL,
  `bookdate` varchar(11) NOT NULL,
  `period` varchar(99) NOT NULL,
  `charge` varchar(255) NOT NULL,
  `liscence_no` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  `payment` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booked`
--

INSERT INTO `booked` (`bid`, `uid`, `car_id`, `bookdate`, `period`, `charge`, `liscence_no`, `status`, `payment`) VALUES
(21, 1, 36, '2022-08-26', '34', '170034', '234325', 0, 0),
(22, 2, 36, '2022-08-24', '3', '15003', '1245364', 0, 0),
(23, 2, 37, '2022-08-24', '344', '172000', '4566', 0, 0),
(24, 2, 36, '2022-08-25', '2', '10002', '123435', 1, 0),
(25, 2, 40, '2022-08-27', '9', '58506465', '345677', 0, 0),
(26, 2, 42, '2022-08-25', '3', '', '3245', 0, 0),
(27, 2, 42, '2022-08-25', '-1', '', 'bcdjc', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `car`
--

CREATE TABLE `car` (
  `car_id` int(255) NOT NULL,
  `brand` varchar(30) NOT NULL,
  `car_name` varchar(11) NOT NULL,
  `number_plate` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `car_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `car`
--

INSERT INTO `car` (`car_id`, `brand`, `car_name`, `number_plate`, `price`, `car_img`) VALUES
(36, 'mahindra', 'Mahindra', '1122', '5001', '../images/mahindra.png'),
(37, 'mahindra', 'Mahindra01', '1133', '500', '../images/mahindra2.png'),
(38, 'tata', 'TATA0', '2345', '500', '../images/tata1.png'),
(39, 'tata', 'TATA2', '56656', '600', '../images/tata3.png'),
(40, 'hyundai', 'HYUNDAI1', '9999', '650', '../images/hyundai.png'),
(41, 'hyundai', 'HYUNDAI2', '5656', '700', '../images/hyundai4.png'),
(42, 'toyota', 'TOYOTA', '76678', '650', '../images/toyota3.png'),
(43, 'toyota', 'TOYOTA1', '6756', '550', '../images/toyota2.png');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `mid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `message` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`mid`, `name`, `email`, `contact`, `message`, `date`) VALUES
(4, 'anoj thapa', 'aanoozthapanpl@gmail.com', '123456', 'ergbe', '2022-08-25'),
(5, 'qedew', 'aanoozthapanpl@gmail.com', '123456', 'fre', '2022-08-25'),
(6, 'sdfb', 'aanoozthapanpl@gmail.com', '9876352321', 'fbfgb', '2022-08-25'),
(7, 'efqe', 'aanoozthapanpl@gmail.com', '9876352321', 'dfdvs', '2022-08-25'),
(8, 'df', 'aanoozthapanpl@gmail.com', '9876352321', 'fdsfvb', '2022-08-25'),
(9, 'dfb', 'aanoozthapanpl@gmail.com', '9876352321', 'wvrbg', '2022-08-25'),
(10, 'reg', 'aanoozthapanpl@gmail.com', '9876352321', 'fdsgsrfb', '2022-08-25'),
(11, 'dfasdf', 'aanoozthapanpl@gmail.com', '9723424234', 'qrwqe', '0000-00-00'),
(12, 'sagsdhgrt', 'npoudelp123@gmail.com', '9862258058', 'fgsdfg', '2022-08-25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(255) NOT NULL,
  `name` varchar(25) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `contact`, `email`, `passwd`, `type`) VALUES
(1, 'admin', '9811318535', 'aanoozthapanpl@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'admin'),
(2, 'Aanoj', '983132321', 'npoudelp123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'client'),
(3, 'bikal ', '981234567', 'bikal123@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 'client'),
(4, 'bibek', '981235456', 'bibek123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'client'),
(5, 'admin', '9000000000', 'admin123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booked`
--
ALTER TABLE `booked`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `car_id` (`car_id`);

--
-- Indexes for table `car`
--
ALTER TABLE `car`
  ADD PRIMARY KEY (`car_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booked`
--
ALTER TABLE `booked`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `car`
--
ALTER TABLE `car`
  MODIFY `car_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booked`
--
ALTER TABLE `booked`
  ADD CONSTRAINT `booked_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`),
  ADD CONSTRAINT `booked_ibfk_2` FOREIGN KEY (`car_id`) REFERENCES `car` (`car_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
