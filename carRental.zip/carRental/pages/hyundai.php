<?php
include("../include/header.php");

?>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark justify-content-center">
        <a class="btn text-warning bg-dark" href="../index.php">Go Back</a>
        <div class="navbar-brand mx-5 ">
            <h2>HYUNDAI</h2>
        </div>
    </nav>
    <br><br>

    <figure>
        <div class="text-center ">
            <img src="../images/hyundai.png" class="img-thumbnail" alt="submit">
            <p>
                <br>Price: </br>
            </p>
            <p><a href="./book.php" class="btn btn-outline-warning">Book Now</a></p>
        </div><br><br>
        <div class="text-center">
            <img src="../images/hyundai1.png" class="img-thumbnail" alt="submit">
            <p>
                <br> Price: </br>
            </p>
            <p><a href="./book.php" class="btn btn-outline-warning">Book Now</a></p>
        </div><br><br>
        <div class="text-center">
            <img src="../images/hyundai2.png" class="img-thumbnail" alt="submit">
            <p>
                <br> Price: </br>
            </p>
            <p><a href="./book.php" class="btn btn-outline-warning">Book Now</a></p>
        </div>
        <br><br>
        <div class="text-center">
            <img src="../images/hyundai3.png" class="img-thumbnail" alt="submit">
            <p>
                <br> Price: </br>
            </p>
            <p><a href="./book.php" class="btn btn-outline-warning">Book Now</a></p>
        </div>
        <br><br>
        <div class="text-center">
            <img src="../images/hyundai4.png" class="img-thumbnail" alt="submit">
            <p>
                <br> Price: </br>
            </p>
            <p><a href="./book.php" class="btn">Book Now</a></p>
        </div>
    </figure>
</body>
<br><br>

<?php
include('../include/footer.php');
?>